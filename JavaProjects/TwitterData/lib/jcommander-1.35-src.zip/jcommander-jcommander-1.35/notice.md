JCommander Copyright Notices 
============================

Copyright 2010 Cedric Beust <cedric@beust.com>

